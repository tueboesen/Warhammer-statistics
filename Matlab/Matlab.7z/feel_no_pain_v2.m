clear all
close all
clc
addpath('./Functions_2')
n=18 %number of shots
dmg = 2 %dmg per shot
hp = 2 %hp of each model
fnp = 1/3 %chance of feel no pain


p = zeros(hp+1,1);
p(end) = 1;
prob = zeros(n+1,hp);
kills = 0;
nc = 0; %current shot
for hp_c = 1:length(p)-1
    if p(hp_c+1) > 0
        [hp_out,nc,kills,prob]=prop_shot(p(hp_c+1),hp_c,dmg,fnp,n,nc,kills,prob);
    end
end


% for i=1:nstates
% end
sum(prob(:))
for i = 1:n+1
    rownames{i} = num2str(i-1);
end
for i = 1:hp
    colnames{i} =  sprintf('Hp_%i',i);   
end
Probabilities = array2table(prob);
Probabilities.Properties.RowNames = rownames;
Probabilities.Properties.VariableNames(1:hp) = colnames

cprob = sum(cumsum(prob,'reverse'),2);

CumProbabilities = array2table(cprob);
CumProbabilities.Properties.RowNames = rownames;
CumProbabilities.Properties.VariableNames(1) = {'Probability'}
