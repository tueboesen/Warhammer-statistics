function [p_out,nc,kills,prob]=prop_shot(p_in,hp,dmg,fnp,n,nc,kills_in,prob)
% hp_in = 2
% nstates = (fnp^-1)^dmg;
% baseprop = fnp^dmg;
max_hp = size(prob,2);
p_out = zeros(hp+1,1);
if nc < n
for i = hp : -1 : max(hp-dmg,0)
    N = dmg;
    k = hp-i;
    p_out(i+1) = fnp^(dmg-k)*(1-fnp)^k*nchoosek(N,k); 
end
p_out(1) =1-sum(p_out(2:end)); %sum probabilities to 1, in case we have lower hp than dmg
p_out = p_in*p_out;
nc = nc+1;
for i = 1:length(p_out)
    if i == 1 
        hp_c = max_hp;
        kills = kills_in+1;
    else
        hp_c = i-1;
        kills = kills_in;
    end
    if p_out(i) > 0
        [~,~,~,prob]=prop_shot(p_out(i),hp_c,dmg,fnp,n,nc,kills,prob);
    end
end
else
%reached the last shot, fill in p  
prob(kills_in+1,hp) = prob(kills_in+1,hp) + p_in; 
kills = kills_in;
end

end